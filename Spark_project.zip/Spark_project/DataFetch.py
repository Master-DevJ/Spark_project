import http.client
import urllib.parse
import json
import csv
from pyspark.sql import SparkSession

# Function to fetch COVID-19 data for a country
def get_country_covid_data(country):
    conn = http.client.HTTPSConnection("covid-193.p.rapidapi.com")
    headers = {
        'X-RapidAPI-Key': "dbf2abe251msh85427ddddf246f8p1cd746jsn984c8dcec84e",
        'X-RapidAPI-Host': "covid-193.p.rapidapi.com"
    }
    encoded_country = urllib.parse.quote(country)  # Encode country name
    conn.request("GET", f"/statistics?country={encoded_country}", headers=headers)
    res = conn.getresponse()
    data = res.read()
    return json.loads(data)

# List of countries to fetch data for
countries = [
    "USA", "Brazil", "India", "Russia", "France",
    "UK", "Italy", "Spain", "Argentina", "Colombia",
    "Germany", "Mexico", "Poland", "Iran", "Peru",
    "South-Africa", "Ukraine", "Indonesia", "Turkey", "Netherlands",
    "Canada", "China", "Australia", "Japan",
    "Saudi-Arabia", "Egypt", "Vietnam", "Israel", "Pakistan",
    "Bangladesh", "Nigeria", "Philippines"
]

# Function to save data to CSV file
def save_to_csv(data, filename):
    with open(filename, mode='w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(["country", "total_cases", "total_deaths", "total_recovered", "active_cases"])
        for country_data in data:
            writer.writerow([
                country_data['country'],
                country_data['cases']['total'],
                country_data['deaths']['total'],
                country_data['cases']['recovered'],
                country_data['cases']['active']
            ])

if __name__ == "__main__":
    # Fetch COVID-19 data for each country
    covid_data = []
    for country in countries:
        data = get_country_covid_data(country)
        if data and data['response']:  # Check if data and response are not empty
            covid_data.append(data['response'][0])
        else:
            print(f"No data found for {country}")

    if not covid_data:
        print("No data found for any country. Please check the API response.")

    # Save data to CSV file
    save_to_csv(covid_data, "covid_data.csv")
    print("Data saved to covid_data.csv")

    # Create SparkSession
    spark = SparkSession.builder \
        .appName("COVID-19 Data") \
        .getOrCreate()

    # Load data into DataFrame
    df = spark.read.csv("covid_data.csv", header=True)

    # Show DataFrame
    df.show()
    
    