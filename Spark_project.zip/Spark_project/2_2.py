from flask import Flask, jsonify
from pyspark.sql import SparkSession
from pyspark.sql.functions import col

# Initialize Flask application
app = Flask(__name__)

# Initialize Spark session
spark = SparkSession.builder \
    .appName("COVID-19 Data API") \
    .getOrCreate()

# Load data into Spark DataFrame
df = spark.read.csv("covid_data.csv", header=True)

@app.route('/least_affected_country', methods=['GET'])
def least_affected_country():
    # Calculate the ratio of total deaths to total COVID cases for each country
    df_with_ratio = df.withColumn("death_to_cases_ratio", col("total_deaths") / col("total_cases"))
    
    # Find the country with the lowest ratio
    least_affected_country = df_with_ratio.orderBy(col("death_to_cases_ratio").asc()).limit(1).collect()[0]
    
    # Prepare the response
    response = {
        'country': least_affected_country['country'],
        'total_cases': least_affected_country['total_cases'],
        'total_deaths': least_affected_country['total_deaths'],
        'total_recovered': least_affected_country['total_recovered'],
        'active_cases': least_affected_country['active_cases'],
        'death_to_cases_ratio': least_affected_country['death_to_cases_ratio']
    }
    
    return jsonify(response)

if __name__ == '__main__':
    app.run(debug=True)
