from flask import Flask, jsonify
from pyspark.sql import SparkSession
from pyspark.sql.functions import col

app = Flask(__name__)

# Create SparkSession
spark = SparkSession.builder \
    .appName("COVID-19 Data API") \
    .getOrCreate()

# Load DataFrame
df = spark.read.csv("covid_data.csv", header=True)

@app.route('/most_affected_country', methods=['GET'])
def most_affected_country():
    # Calculate the ratio of total deaths to total COVID cases for each country
    df_with_ratio = df.withColumn("death_to_cases_ratio", col("total_deaths") / col("total_cases"))
    
    # Find the country with the highest ratio
    most_affected_country = df_with_ratio.orderBy(col("death_to_cases_ratio").desc()).limit(1).collect()[0]
    
    # Prepare the response
    response = {
        'country': most_affected_country['country'],
        'total_cases': most_affected_country['total_cases'],
        'total_deaths': most_affected_country['total_deaths'],
        'total_recovered': most_affected_country['total_recovered'],
        'active_cases': most_affected_country['active_cases'],
        'death_to_cases_ratio': most_affected_country['death_to_cases_ratio']
    }
    
    return jsonify(response)

if __name__ == '__main__':
    app.run(debug=True)
