from flask import Flask, jsonify
from pyspark.sql import SparkSession
from pyspark.sql.functions import col

# Initialize Flask application
app = Flask(__name__)

# Initialize Spark session
spark = SparkSession.builder \
    .appName("COVID-19 Data API") \
    .getOrCreate()

# Load data into Spark DataFrame
df = spark.read.csv("covid_data.csv", header=True)

@app.route('/least_efficient_country', methods=['GET'])
def least_efficient_country():
    # Filter out rows with null values in total_recovered or total_cases
    df_filtered = df.filter((col("total_recovered").isNotNull()) & (col("total_cases").isNotNull()))
    
    # Calculate the ratio of total recoveries to total COVID cases for each country
    df_efficiency = df_filtered.select(col("country"), (col("total_recovered").cast("int") / col("total_cases").cast("int")).alias("efficiency"))
    
    # Find the country with the lowest efficiency
    least_efficient_country = df_efficiency.orderBy(col("efficiency")).first()
    
    # Prepare the response
    response = {
        'country': least_efficient_country['country'],
        'efficiency': least_efficient_country['efficiency']
    }
    
    return jsonify(response)

if __name__ == '__main__':
    app.run(debug=True)
