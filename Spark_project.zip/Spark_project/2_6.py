from flask import Flask, jsonify
from pyspark.sql import SparkSession
from pyspark.sql.functions import col

# Initialize Flask application
app = Flask(__name__)

# Initialize Spark session
spark = SparkSession.builder \
    .appName("COVID-19 Data API") \
    .getOrCreate()

# Load data into Spark DataFrame
df = spark.read.csv("covid_data.csv", header=True)

@app.route('/most_efficient_country', methods=['GET'])
def most_efficient_country():
    # Calculate the ratio of total recoveries to total COVID cases for each country
    df_efficiency = df.select(col("country"), (col("total_recovered").cast("int") / col("total_cases").cast("int")).alias("efficiency"))
    
    # Find the country with the highest efficiency
    most_efficient_country = df_efficiency.orderBy(col("efficiency").desc()).first()
    
    # Prepare the response
    response = {
        'country': most_efficient_country['country'],
        'efficiency': most_efficient_country['efficiency']
    }
    
    return jsonify(response)

if __name__ == '__main__':
    app.run(debug=True)
