from flask import Flask, jsonify
from pyspark.sql import SparkSession
from pyspark.sql.functions import col

# Initialize Flask application
app = Flask(__name__)

# Initialize Spark session
spark = SparkSession.builder \
    .appName("COVID-19 Data API") \
    .getOrCreate()

# Load data into Spark DataFrame
df = spark.read.csv("covid_data.csv", header=True)

@app.route('/total_cases', methods=['GET'])
def total_cases():
    # Calculate the total number of COVID cases
    total_cases = df.select(col("total_cases").cast("int")).agg({"total_cases": "sum"}).collect()[0][0]
    
    # Prepare the response
    response = {
        'total_cases': total_cases
    }
    
    return jsonify(response)

if __name__ == '__main__':
    app.run(debug=True)
