from flask import Flask, jsonify
from pyspark.sql import SparkSession
from pyspark.sql.functions import col

# Initialize Flask application
app = Flask(__name__)

# Initialize Spark session
spark = SparkSession.builder \
    .appName("COVID-19 Data API") \
    .getOrCreate()

# Load data into Spark DataFrame
df = spark.read.csv("covid_data.csv", header=True)

@app.route('/country_with_minimum_cases', methods=['GET'])
def country_with_minimum_cases():
    # Find the country with the minimum number of COVID cases
    minimum_cases_country = df.orderBy(col("total_cases").cast("int").asc()).first()
    
    # Prepare the response
    response = {
        'country': minimum_cases_country['country'],
        'total_cases': minimum_cases_country['total_cases'],
        'total_deaths': minimum_cases_country['total_deaths'],
        'total_recovered': minimum_cases_country['total_recovered'],
        'active_cases': minimum_cases_country['active_cases']
    }
    
    return jsonify(response)

if __name__ == '__main__':
    app.run(debug=True)
