from flask import Flask, jsonify
from pyspark.sql import SparkSession
from pyspark.sql.functions import col

# Initialize Flask application
app = Flask(__name__)

# Initialize Spark session
spark = SparkSession.builder \
    .appName("COVID-19 Data API") \
    .getOrCreate()

# Load data into Spark DataFrame
df = spark.read.csv("covid_data.csv", header=True)

@app.route('/least_active_country', methods=['GET'])
def least_active_country():
    # Filter out rows with null values in active cases
    df_filtered = df.filter(col("active_cases").isNotNull())
    
    # Find the country with the least active cases
    least_active_country = df_filtered.orderBy(col("active_cases")).first()
    
    # Prepare the response
    response = {
        'country': least_active_country['country'],
        'active_cases': least_active_country['active_cases']
    }
    
    return jsonify(response)

if __name__ == '__main__':
    app.run(debug=True)
