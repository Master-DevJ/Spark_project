from flask import Flask, jsonify
from pyspark.sql import SparkSession

app = Flask(__name__)

# Function to load data from CSV file into a Spark DataFrame
def load_data():
    spark = SparkSession.builder \
        .appName("COVID-19 Data API") \
        .getOrCreate()
    df = spark.read.csv("covid_data.csv", header=True)
    return df

# Route to get all data
@app.route('/api/data', methods=['GET'])
def get_data():
    df = load_data()
    data = df.collect()  # Collect all data from DataFrame
    return jsonify(data)

# Route to get data by country
@app.route('/api/data/<country>', methods=['GET'])
def get_data_by_country(country):
    df = load_data()
    country_data = df.filter(df.country == country).collect()  # Filter data by country
    if not country_data:
        return jsonify({'error': 'Country not found'}), 404
    return jsonify(country_data)

if __name__ == '__main__':
    app.run(debug=True)
